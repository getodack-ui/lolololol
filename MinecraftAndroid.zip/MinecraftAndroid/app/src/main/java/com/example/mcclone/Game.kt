package com.example.mcclone

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Rect
import android.opengl.GLES20
import android.opengl.GLSurfaceView
import android.opengl.GLUtils
import android.opengl.Matrix
import java.io.File
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.nio.FloatBuffer
import java.util.Random
import java.util.zip.ZipFile
import javax.microedition.khronos.egl.EGLConfig
import javax.microedition.khronos.opengles.GL10
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.floor
import kotlin.math.min
import kotlin.math.sin

const val W = 128
const val D = 128
const val H = 64

val NAMES = arrayOf("grass_block_top", "grass_block_side", "dirt", "stone", "sand", "oak_log", "oak_log_top", "oak_leaves", "oak_planks", "cobblestone")
val FALL = intArrayOf(0xFF5FA03C.toInt(), 0xFF7A5A3A.toInt(), 0xFF86603F.toInt(), 0xFF7F7F7F.toInt(), 0xFFDBD3A0.toInt(),
    0xFF6B5030.toInt(), 0xFF9C7F4E.toInt(), 0xFF3C8C2A.toInt(), 0xFFA0804A.toInt(), 0xFF6E6E6E.toInt())
val BLOCKS = arrayOf("Трава", "Земля", "Камень", "Песок", "Бревно", "Листва", "Доски", "Булыжник")

// порядок граней: +X, -X, +Y, -Y, +Z, -Z ; 4 угла * (x,y,z,u,v)
val F = arrayOf(
    floatArrayOf(1f,0f,1f,0f,1f, 1f,0f,0f,1f,1f, 1f,1f,0f,1f,0f, 1f,1f,1f,0f,0f),
    floatArrayOf(0f,0f,0f,0f,1f, 0f,0f,1f,1f,1f, 0f,1f,1f,1f,0f, 0f,1f,0f,0f,0f),
    floatArrayOf(0f,1f,1f,0f,1f, 1f,1f,1f,1f,1f, 1f,1f,0f,1f,0f, 0f,1f,0f,0f,0f),
    floatArrayOf(0f,0f,0f,0f,0f, 1f,0f,0f,1f,0f, 1f,0f,1f,1f,1f, 0f,0f,1f,0f,1f),
    floatArrayOf(0f,0f,1f,0f,1f, 1f,0f,1f,1f,1f, 1f,1f,1f,1f,0f, 0f,1f,1f,0f,0f),
    floatArrayOf(1f,0f,0f,0f,1f, 0f,0f,0f,1f,1f, 0f,1f,0f,1f,0f, 1f,1f,0f,0f,0f)
)
val NB = arrayOf(intArrayOf(1,0,0), intArrayOf(-1,0,0), intArrayOf(0,1,0), intArrayOf(0,-1,0), intArrayOf(0,0,1), intArrayOf(0,0,-1))
val SHADE = floatArrayOf(.8f, .8f, 1f, .5f, .65f, .65f)

fun tile(b: Int, f: Int): Int = when (b) {
    1 -> if (f == 2) 0 else if (f == 3) 2 else 1
    2 -> 2
    3 -> 3
    4 -> 4
    5 -> if (f == 2 || f == 3) 6 else 5
    6 -> 7
    7 -> 8
    else -> 9
}

class Buf {
    var a = FloatArray(1 shl 16)
    var n = 0
    fun v(x: Float, y: Float, z: Float, u: Float, w: Float, s: Float) {
        if (n + 6 > a.size) a = a.copyOf(a.size * 2)
        a[n++] = x; a[n++] = y; a[n++] = z; a[n++] = u; a[n++] = w; a[n++] = s
    }
}

class World {
    val b = ByteArray(W * H * D)
    fun idx(x: Int, y: Int, z: Int) = (y * D + z) * W + x
    fun get(x: Int, y: Int, z: Int): Int =
        if (y < 0 || x < 0 || z < 0 || x >= W || z >= D) 3 else if (y >= H) 0 else b[idx(x, y, z)].toInt()
    fun set(x: Int, y: Int, z: Int, v: Int) {
        if (x in 0 until W && y in 0 until H && z in 0 until D) b[idx(x, y, z)] = v.toByte()
    }
    fun height(x: Int, z: Int): Int =
        (26 + 6 * sin(x * 0.05) + 5 * sin(z * 0.07 + 1) + 3 * sin((x + z) * 0.13) + 2 * sin(x * 0.31) * sin(z * 0.27)).toInt()

    init {
        for (x in 0 until W) for (z in 0 until D) {
            val h = height(x, z)
            for (y in 0..h) {
                val sand = h <= 24
                set(x, y, z, if (y == h) (if (sand) 4 else 1) else if (y >= h - 3) (if (sand) 4 else 2) else 3)
            }
        }
        val r = Random(42)
        for (x in 4 until W - 4) for (z in 4 until D - 4) {
            val h = height(x, z)
            if (h > 24 && r.nextInt(70) == 0) {
                val t = 4 + r.nextInt(2)
                for (y in 1..t) set(x, h + y, z, 5)
                for (dx in -2..2) for (dz in -2..2) for (dy in t - 1..t + 1) {
                    if (abs(dx) + abs(dz) + (dy - t + 1) < 4 && get(x + dx, h + dy, z + dz) == 0) set(x + dx, h + dy, z + dz, 6)
                }
            }
        }
    }
}

class Game(private val jar: File?) : GLSurfaceView.Renderer {
    private val w = World()
    @Volatile var yaw = 0f
    @Volatile var pitch = 0f
    @Volatile var mvx = 0f
    @Volatile var mvz = 0f
    @Volatile var jump = false
    @Volatile var act = 0
    var onSel: ((String) -> Unit)? = null
    private var sel = 3
    private var px = 64.5f
    private var py = 0f
    private var pz = 64.5f
    private var vy = 0f
    private var ground = false

    private val meshes = arrayOfNulls<FloatBuffer>(64)
    private val cnt = IntArray(64)
    private val dirty = BooleanArray(64) { true }
    private var prog = 0; private var aP = 0; private var aT = 0; private var aS = 0; private var uM = 0
    private var tex = 0; private var sw = 1; private var sh = 1; private var last = 0L
    private val proj = FloatArray(16); private val view = FloatArray(16); private val mvp = FloatArray(16)

    init { py = (w.height(64, 64) + 2).toFloat() }

    fun cycle() { sel = sel % 8 + 1; onSel?.invoke("Блок: " + BLOCKS[sel - 1]) }

    private fun atlas(): Bitmap {
        val out = Bitmap.createBitmap(64, 64, Bitmap.Config.ARGB_8888)
        val cv = Canvas(out)
        val zip = try { jar?.let { ZipFile(it) } } catch (e: Exception) { null }
        for (t in 0 until 10) {
            var src: Bitmap? = null
            try {
                val ent = zip?.getEntry("assets/minecraft/textures/block/${NAMES[t]}.png")
                if (ent != null) src = BitmapFactory.decodeStream(zip!!.getInputStream(ent))
            } catch (e: Exception) { }
            val tl = Bitmap.createBitmap(16, 16, Bitmap.Config.ARGB_8888)
            if (src == null) tl.eraseColor(FALL[t])
            else Canvas(tl).drawBitmap(src, Rect(0, 0, src.width, min(src.width, src.height)), Rect(0, 0, 16, 16), null)
            if (t == 0 || t == 7) {
                val tc = if (t == 0) 0x79C05A else 0x48B518
                for (x in 0 until 16) for (y in 0 until 16) {
                    val p = tl.getPixel(x, y)
                    val r = ((p shr 16) and 255) * ((tc shr 16) and 255) / 255
                    val gg = ((p shr 8) and 255) * ((tc shr 8) and 255) / 255
                    val bb = (p and 255) * (tc and 255) / 255
                    tl.setPixel(x, y, (p and 0xFF000000.toInt()) or (r shl 16) or (gg shl 8) or bb)
                }
            }
            cv.drawBitmap(tl, (t % 4) * 16f, (t / 4) * 16f, null)
        }
        return out
    }

    private fun shader(type: Int, s: String): Int {
        val i = GLES20.glCreateShader(type); GLES20.glShaderSource(i, s); GLES20.glCompileShader(i); return i
    }

    override fun onSurfaceCreated(gl: GL10?, c: EGLConfig?) {
        GLES20.glEnable(GLES20.GL_DEPTH_TEST)
        prog = GLES20.glCreateProgram()
        GLES20.glAttachShader(prog, shader(GLES20.GL_VERTEX_SHADER,
            "uniform mat4 uM;attribute vec3 aP;attribute vec2 aT;attribute float aS;varying vec2 vT;varying float vS;" +
            "void main(){gl_Position=uM*vec4(aP,1.0);vT=aT;vS=aS;}"))
        GLES20.glAttachShader(prog, shader(GLES20.GL_FRAGMENT_SHADER,
            "precision mediump float;uniform sampler2D uTex;varying vec2 vT;varying float vS;" +
            "void main(){vec4 c=texture2D(uTex,vT);if(c.a<0.5)discard;gl_FragColor=vec4(c.rgb*vS,1.0);}"))
        GLES20.glLinkProgram(prog)
        aP = GLES20.glGetAttribLocation(prog, "aP"); aT = GLES20.glGetAttribLocation(prog, "aT")
        aS = GLES20.glGetAttribLocation(prog, "aS"); uM = GLES20.glGetUniformLocation(prog, "uM")
        val t = IntArray(1); GLES20.glGenTextures(1, t, 0); tex = t[0]
        GLES20.glBindTexture(GLES20.GL_TEXTURE_2D, tex)
        GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_MIN_FILTER, GLES20.GL_NEAREST)
        GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_MAG_FILTER, GLES20.GL_NEAREST)
        GLUtils.texImage2D(GLES20.GL_TEXTURE_2D, 0, atlas(), 0)
        for (i in 0 until 64) dirty[i] = true
    }

    override fun onSurfaceChanged(gl: GL10?, ww: Int, hh: Int) {
        GLES20.glViewport(0, 0, ww, hh); sw = ww; sh = hh
        Matrix.perspectiveM(proj, 0, 70f, ww / hh.toFloat(), 0.1f, 200f)
    }

    private fun build(i: Int) {
        dirty[i] = false
        val cx = i % 8; val cz = i / 8
        val bf = Buf()
        for (x in cx * 16 until cx * 16 + 16) for (z in cz * 16 until cz * 16 + 16) for (y in 0 until H) {
            val b = w.get(x, y, z)
            if (b == 0) continue
            for (f in 0 until 6) {
                val n = NB[f]
                val nb = w.get(x + n[0], y + n[1], z + n[2])
                if (nb != 0 && nb != 6) continue
                val t = tile(b, f)
                val tu = (t % 4) / 4f; val tv = (t / 4) / 4f
                val q = F[f]
                for (k in intArrayOf(0, 1, 2, 0, 2, 3)) {
                    bf.v(x + q[k * 5], y + q[k * 5 + 1], z + q[k * 5 + 2], tu + q[k * 5 + 3] * 0.25f, tv + q[k * 5 + 4] * 0.25f, SHADE[f])
                }
            }
        }
        cnt[i] = bf.n / 6
        meshes[i] = if (bf.n == 0) null else
            ByteBuffer.allocateDirect(bf.n * 4).order(ByteOrder.nativeOrder()).asFloatBuffer().apply { put(bf.a, 0, bf.n); position(0) }
    }

    private fun mark(x: Int, z: Int) {
        for (a in intArrayOf(x - 1, x, x + 1)) for (c in intArrayOf(z - 1, z, z + 1))
            if (a in 0 until W && c in 0 until D) dirty[(c / 16) * 8 + a / 16] = true
    }

    private fun hit(x: Float, y: Float, z: Float): Boolean {
        for (xi in floor(x - 0.3f).toInt()..floor(x + 0.3f).toInt())
            for (yi in floor(y).toInt()..floor(y + 1.8f).toInt())
                for (zi in floor(z - 0.3f).toInt()..floor(z + 0.3f).toInt())
                    if (w.get(xi, yi, zi) != 0) return true
        return false
    }

    private fun ray(): IntArray? {
        val yr = Math.toRadians(yaw.toDouble()); val pr = Math.toRadians(pitch.toDouble())
        val dx = (sin(yr) * cos(pr)).toFloat(); val dy = sin(pr).toFloat(); val dz = (-cos(yr) * cos(pr)).toFloat()
        var lx = -1; var ly = -1; var lz = -1
        var t = 0f
        while (t < 6f) {
            val x = floor(px + dx * t).toInt(); val y = floor(py + 1.62f + dy * t).toInt(); val z = floor(pz + dz * t).toInt()
            if (w.get(x, y, z) != 0) return intArrayOf(x, y, z, lx, ly, lz)
            lx = x; ly = y; lz = z; t += 0.02f
        }
        return null
    }

    private fun step(dt: Float) {
        val s = sin(Math.toRadians(yaw.toDouble())).toFloat(); val c = cos(Math.toRadians(yaw.toDouble())).toFloat()
        val f = -mvz; val r = mvx
        val vx = (f * s + r * c) * 4.5f; val vz = (-f * c + r * s) * 4.5f
        if (jump) { if (ground) vy = 8.5f; jump = false }
        vy -= 25f * dt
        var n = px + vx * dt; if (!hit(n, py, pz)) px = n
        n = pz + vz * dt; if (!hit(px, py, n)) pz = n
        n = py + vy * dt
        if (!hit(px, n, pz)) { py = n; ground = false } else { ground = vy < 0; vy = 0f }
        if (py < -10f) { py = 60f; vy = 0f }
        val a = act
        if (a != 0) {
            act = 0
            val h = ray()
            if (h != null) {
                if (a == 1) { if (h[1] > 0) { w.set(h[0], h[1], h[2], 0); mark(h[0], h[2]) } }
                else if (h[3] >= 0) {
                    w.set(h[3], h[4], h[5], sel)
                    if (hit(px, py, pz)) w.set(h[3], h[4], h[5], 0) else mark(h[3], h[5])
                }
            }
        }
    }

    override fun onDrawFrame(gl: GL10?) {
        val now = System.nanoTime()
        val dt = if (last == 0L) 0.016f else min(0.05f, (now - last) / 1e9f)
        last = now
        step(dt)
        var built = 0
        for (i in 0 until 64) if (dirty[i] && built < 8) { build(i); built++ }
        GLES20.glClearColor(0.53f, 0.81f, 0.92f, 1f)
        GLES20.glClear(GLES20.GL_COLOR_BUFFER_BIT or GLES20.GL_DEPTH_BUFFER_BIT)
        Matrix.setIdentityM(view, 0)
        Matrix.rotateM(view, 0, -pitch, 1f, 0f, 0f)
        Matrix.rotateM(view, 0, yaw, 0f, 1f, 0f)
        Matrix.translateM(view, 0, -px, -(py + 1.62f), -pz)
        Matrix.multiplyMM(mvp, 0, proj, 0, view, 0)
        GLES20.glUseProgram(prog)
        GLES20.glUniformMatrix4fv(uM, 1, false, mvp, 0)
        GLES20.glActiveTexture(GLES20.GL_TEXTURE0)
        GLES20.glBindTexture(GLES20.GL_TEXTURE_2D, tex)
        GLES20.glEnableVertexAttribArray(aP); GLES20.glEnableVertexAttribArray(aT); GLES20.glEnableVertexAttribArray(aS)
        for (i in 0 until 64) {
            val m = meshes[i] ?: continue
            m.position(0); GLES20.glVertexAttribPointer(aP, 3, GLES20.GL_FLOAT, false, 24, m)
            m.position(3); GLES20.glVertexAttribPointer(aT, 2, GLES20.GL_FLOAT, false, 24, m)
            m.position(5); GLES20.glVertexAttribPointer(aS, 1, GLES20.GL_FLOAT, false, 24, m)
            GLES20.glDrawArrays(GLES20.GL_TRIANGLES, 0, cnt[i])
        }
        // прицел
        GLES20.glEnable(GLES20.GL_SCISSOR_TEST)
        GLES20.glClearColor(1f, 1f, 1f, 1f)
        GLES20.glScissor(sw / 2 - 1, sh / 2 - 10, 2, 20); GLES20.glClear(GLES20.GL_COLOR_BUFFER_BIT)
        GLES20.glScissor(sw / 2 - 10, sh / 2 - 1, 20, 2); GLES20.glClear(GLES20.GL_COLOR_BUFFER_BIT)
        GLES20.glDisable(GLES20.GL_SCISSOR_TEST)
    }
}
