package com.example.mcclone

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.opengl.GLSurfaceView
import android.os.Bundle
import android.view.MotionEvent
import android.view.WindowManager
import android.widget.Toast
import java.io.File
import kotlin.math.abs

class MainActivity : Activity() {
    private lateinit var view: GameView

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        val jar = File(filesDir, "client.jar")
        view = GameView(this, if (jar.exists()) jar else null)
        setContentView(view)
        if (!jar.exists()) {
            Toast.makeText(this, "Выбери client.jar (или ресурспак .zip) из своего Minecraft", Toast.LENGTH_LONG).show()
            startActivityForResult(Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
                addCategory(Intent.CATEGORY_OPENABLE); type = "*/*"
            }, 1)
        }
    }

    @Deprecated("simple picker")
    override fun onActivityResult(r: Int, c: Int, d: Intent?) {
        val u = d?.data ?: return
        contentResolver.openInputStream(u)?.use { i ->
            File(filesDir, "client.jar").outputStream().use { o -> i.copyTo(o) }
        }
        recreate()
    }

    override fun onPause() { super.onPause(); view.onPause() }
    override fun onResume() { super.onResume(); view.onResume() }
}

class GameView(private val ctx: Context, jar: File?) : GLSurfaceView(ctx) {
    private val g = Game(jar)
    private var moveId = -1; private var lookId = -1
    private var mx = 0f; private var my = 0f; private var mT = 0L; private var mMoved = false
    private var lx = 0f; private var ly = 0f; private var lT = 0L; private var lMoved = false

    init {
        setEGLContextClientVersion(2)
        setEGLConfigChooser(8, 8, 8, 8, 16, 0)
        setRenderer(g)
        g.onSel = { n -> post { Toast.makeText(ctx, n, Toast.LENGTH_SHORT).show() } }
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        val i = e.actionIndex
        val id = e.getPointerId(i)
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN, MotionEvent.ACTION_POINTER_DOWN -> {
                val x = e.getX(i); val y = e.getY(i)
                if (x < width / 2f) {
                    if (moveId < 0) { moveId = id; mx = x; my = y; mT = e.eventTime; mMoved = false }
                } else if (x > width * 0.85f && y < height * 0.15f) {
                    g.cycle()
                } else if (lookId < 0) {
                    lookId = id; lx = x; ly = y; lT = e.eventTime; lMoved = false
                }
            }
            MotionEvent.ACTION_MOVE -> for (k in 0 until e.pointerCount) {
                val pid = e.getPointerId(k)
                val x = e.getX(k); val y = e.getY(k)
                if (pid == moveId) {
                    g.mvx = ((x - mx) / 120f).coerceIn(-1f, 1f)
                    g.mvz = ((y - my) / 120f).coerceIn(-1f, 1f)
                    if (abs(x - mx) > 25 || abs(y - my) > 25) mMoved = true
                } else if (pid == lookId) {
                    g.yaw += (x - lx) * 0.25f
                    g.pitch = (g.pitch - (y - ly) * 0.25f).coerceIn(-89f, 89f)
                    if (abs(x - lx) + abs(y - ly) > 2f) lMoved = true
                    lx = x; ly = y
                }
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_POINTER_UP, MotionEvent.ACTION_CANCEL -> {
                if (id == moveId) {
                    moveId = -1; g.mvx = 0f; g.mvz = 0f
                    if (!mMoved && e.eventTime - mT < 220) g.jump = true
                } else if (id == lookId) {
                    lookId = -1
                    if (!lMoved) g.act = if (e.eventTime - lT < 250) 1 else 2
                }
            }
        }
        return true
    }
}
